# 客户端快速上手（Windows / Linux）

本客户端采用平台托管配置：你只需要控制台地址和一次性绑定码。传统 frpc 的“服务器地址、服务器端口、专属密钥”由平台按设备自动下发，隧道创建后自动更新，无需手工编辑 TOML。客户端与 `frpc` 程序必须放在同一目录。[从仓库发布目录下载对应系统的压缩包](https://github.com/huang199800/frp-business/tree/main/releases/v0.2.0)。

## 先在网页做两件事

1. 打开 <https://frpc.hhse.top> 注册并登录。向运营方领取充值码，在“充值续费”兑换。没有有效套餐时，设备不能建立转发。
2. 在“我的设备”输入易识别的设备名称，点击“生成 5 分钟绑定码”。保持页面打开，稍后把码粘贴到客户端。码只能用一次；过期就重新生成。

## Windows 10/11（amd64）

1. 下载 `frp-portal-client-0.2.0-windows-amd64.zip`，解压到任意文件夹。
2. 在解压文件夹的地址栏输入 `powershell` 并回车，打开 PowerShell。
3. 执行 `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\install-client-windows.ps1`，按提示粘贴绑定码。脚本把程序放在当前用户目录，创建“FRPPortal-Client”登录启动任务；不需要把管理员密码写入配置。
4. 在网页“隧道管理”新建 TCP 隧道，选择刚绑定的设备，填本地端口。例如本机 SSH 用 `127.0.0.1:22`，本机网站用 `127.0.0.1:80`；公网端口填 `0` 让平台自动分配。
5. 在别的网络访问网页显示的 `节点地址:远程端口`。先确认本机服务自己能连通。

临时运行而不安装登录任务：在解压目录执行 `.\portal.exe connect`，输入绑定码；窗口关闭后转发停止。已安装的客户端换新压缩包时，重新运行上面的安装脚本即可；原设备配置在 `%APPDATA%\frp-portal\agent.json`，不要删除或分享。

## Linux（amd64 / arm64）

1. 下载与 `uname -m` 对应的 `frp-portal-client-0.2.0-linux-amd64.zip`（x86_64）或 `...-arm64.zip`（aarch64），解压。
2. 在解压目录运行 `bash scripts/install-client-linux.sh https://frpc.hhse.top`，按提示输入绑定码。脚本安装当前用户的 systemd 服务并立即启动。
3. 创建隧道后运行 `systemctl --user status frp-portal-agent` 查看状态；若需退出当前登录会话后仍运行，请由服务器管理员执行 `sudo loginctl enable-linger 用户名`。

临时运行可在解压目录执行 `./portal connect --control-url https://frpc.hhse.top`。若使用其他平台，把命令中的地址换成那个控制台的 HTTPS 域名。安装脚本可重复运行来更新客户端二进制，原设备凭据会保留。

## 和普通 frpc 参数的对应关系

| 普通 frpc 参数 | 本平台行为 |
| --- | --- |
| Server Address / Server Port | 按套餐节点和设备自动分配并下发 |
| Auth Token | 设备专属密钥，绑定后只保存在本机受保护配置中 |
| User Prefix | 平台用唯一隧道 ID 隔离账号，不要求用户输入前缀 |
| Transport Protocol | 默认 TCP |
| Pool Count | 默认 0；高级参数 `portal connect --pool-count 1` 可设 0–10 |
| TCP 多路复用 | 默认开启；高级参数 `--tcp-mux=false` 可关闭 |
| Log Level / Max Log Days | 默认 Error / 7 天；高级参数 `--log-level warn --max-log-days 14` |

高级参数在**首次绑定前**设置；已绑定设备请直接编辑自己的 `agent.json` 对应字段并重启客户端。`frpc.log` 位于该配置旁的 `state` 目录。不要更改自动下发的令牌、服务器端口或隧道 ID，它们与服务端授权绑定。

若连接失败，先检查套餐有效期、设备/节点是否被禁用、本地服务端口是否监听，以及云安全组是否放行公网远程端口。客户端配置目录中的 `agent.json` 含设备密钥，不要上传到论坛或发给客服；需要撤销时在网页“我的设备”点击“撤销凭据”。
